﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge_POO_Version1
{
    class CAttraction
    {
        // CLASS ABSTRACT
        //Les attributs permettant le constructeur de toutes les attractions
        protected int m_identifiantInt;
        protected string m_nomStr;
        protected int m_nbMinMonstreInt;
        protected bool m_besoinSpecifiqueBool;
        protected string m_typeDeBesoinStr;
        //Les autres attributs permettant de completer les informations sur une attraction
        protected TimeSpan m_dureeMaintenanceTimeSpan;
        protected List<CMonstre> m_equipeListMonstre;
        protected bool m_maintenanceBool;
        protected string m_natureMaintenanceStr;
        protected bool m_ouvertBool;

        public int IdentifiantInt
        {
            get { return m_identifiantInt; }
        }

        public CAttraction(int identifiant, string nom, int nbMinMonstre, bool besoinSpecifique, string typeDeBesoin)
        {
            m_identifiantInt = identifiant;
            m_nomStr = nom;
            m_nbMinMonstreInt = nbMinMonstre;
            m_besoinSpecifiqueBool = besoinSpecifique;
            m_typeDeBesoinStr = typeDeBesoin;
        }
        public CAttraction(int identifiant)
        {
            if (identifiant != 0) m_identifiantInt = identifiant;
            else
            {
                Console.WriteLine("\nL'attraction qui va être affectée a un ID de 0 !! => Appuyer sur une touche pour continuer");
                Console.ReadKey();
            }
        }
    }
}
