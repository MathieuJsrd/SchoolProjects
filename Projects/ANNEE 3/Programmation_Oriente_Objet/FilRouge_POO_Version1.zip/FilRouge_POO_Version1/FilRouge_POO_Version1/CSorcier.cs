﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge_POO_Version1
{
    class CSorcier : CPersonnel
    {
        private List<string> m_pouvoirsListStr;
        private Grade m_tatouageGrade;

        public CSorcier(int matricule, string nom, string prenom, TypeSexe sexe, string fonction, Grade tatouage, List<string> pouvoirs):base(matricule,nom,prenom,sexe,fonction)
        {
            m_tatouageGrade = tatouage;
            m_pouvoirsListStr = pouvoirs;
        }
    }
}
