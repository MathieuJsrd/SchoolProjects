﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge_POO_Version1
{
    class CRollerCoaster : CAttraction
    {
        private int m_ageMinimumInt;
        private TypeCategorie m_categorie;
        private float m_tailleMinimumFloat;
        public CRollerCoaster(int identifiant, string nom, int nbMinMonstre, bool besoinSpecifique, string typeDeBesoin, TypeCategorie categorie, int ageMinimum, float tailleMinimum):base(identifiant,nom,nbMinMonstre,besoinSpecifique,typeDeBesoin)
        {
            m_ageMinimumInt = ageMinimum;
            m_categorie = categorie;
            m_tailleMinimumFloat = tailleMinimum;
        }

    }
}
