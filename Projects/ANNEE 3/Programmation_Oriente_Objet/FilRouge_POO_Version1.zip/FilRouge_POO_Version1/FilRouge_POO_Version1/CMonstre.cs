﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge_POO_Version1
{
    class CMonstre : CPersonnel
    {
        protected CAttraction m_affectationAttra;
        protected int m_cagnotteInt;

        public CMonstre(int matricule, string nom, string prenom, TypeSexe sexe, string fonction, int cagnotte, CAttraction affectation):base(matricule,nom,prenom,sexe,fonction)
        {
            m_affectationAttra = affectation;
            m_cagnotteInt = cagnotte;
        }
        public CMonstre(int matricule, string nom, string prenom, TypeSexe sexe, string fonction, int cagnotte, int affectationAttractionInt) : base(matricule, nom, prenom, sexe, fonction)
        {
            m_cagnotteInt = cagnotte;
            m_affectationAttra = new CAttraction(affectationAttractionInt);
        }
        public string AjouterUneAffectationAttraction(CAttraction affectation)
        {
            string messageReturned = "";
            if (m_affectationAttra == null)
            {
                m_affectationAttra = affectation;
                messageReturned = "L'attraction " + affectation.IdentifiantInt + " a été affecté au monstre\n";
            }
            else
            {
                messageReturned = "L'attraction " + affectation.IdentifiantInt + " est déjà affectée. Voulez-vous changer ?\n";
            }
            return messageReturned;
        }
    }
}
