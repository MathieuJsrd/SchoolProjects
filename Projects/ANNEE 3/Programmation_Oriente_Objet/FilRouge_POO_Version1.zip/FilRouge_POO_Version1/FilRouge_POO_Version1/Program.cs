﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FilRouge_POO_Version1
{
    class Program
    {
        static void Main(string[] args)
        {
            //TO DO
            // S'occuper des neants qui sont les membres de la direction


            //CPersonnel P1 = new CPersonnel(211536, "Josserand", "Mathieu", TypeSexe.male, "serveur");
            //CPersonnel P2 = new CPersonnel(211537, "Josserand", "Paul", TypeSexe.male, "plongeur");
            //Console.WriteLine(P1.DisplayObject());
            //Console.WriteLine(P2.DisplayObject());
            LectureFichierCSV("Listing.csv");
            //LectureFichierCSV("ClasseurTest.csv");
            //DisplayTabStr(TabtDesPouvoirsSorciersFromCSV("telekinesie-transformation d'objets"));
            Console.ReadKey();
            
        }


        
        // S'OCCUPER DES CONVERT
        static void LectureFichierCSV(string nomFichier)
        {
            List<CSorcier> listDesSorciers = new List<CSorcier>();
            int i = 1;
            try
            {
                #region Test De la validé du fichier entré en paramètre
                StreamReader monStreamReader = new StreamReader(nomFichier);
                //On déclare une string pour la lecture ligne par ligne du fichier .csv
                string ligneLuStr = monStreamReader.ReadLine(); //Lecture de la premiere ligne
                //Tant que l'on est pas à la fin du fichier
                //Installation d'un compteur

                while(ligneLuStr != null)
                {
                    try
                    {
                        //Chaque mot dans le fichier est séparé par un ;
                        string[] TabStr = ligneLuStr.Split(';'); // Toutes les cases sont contenues dans le tab de string
                                                                 //DisplayTabStr(tempTabStr);
                        if (TabStr[0] == "Sorcier")
                        {
                            #region Condition pour creer un sorcier
                            //NOUS NOUS OCCUPONS D'UN SORCIER
                            //Il faut enlever les deux dernieres cases du tableau car il fait automatiquement 10 de taille
                            string[] tempTabStr = new string[8]; // 7 attributs + 1 case "sorcier"
                            for (int index = 0; index < tempTabStr.Length; index++)
                            {
                                tempTabStr[index] = TabStr[index];
                            }
                            //On se retrouve du coup avec un tableau de 8 comme prévu pour le sorcier
                            //DisplayTabStr(tempTabStr);
                            //Le but est de blinder ce que l'on va pouvoir lire sur le fichier pour faciliter le constructeur ensuite
                            if (tempTabStr.Length == 8) // car contient 7 attributs + 1 pour la premiere case
                                                                                                                                           // Concernant les conditions d'entrées : soit 6 des 7 attributs sont remplis et le dernier pour le pouvoir est null OK
                                                                                                                                           // Soit les 7 sont entrées et c'est OK
                                                                                                                                           // Dans les 2 cas, on prend soin de vérifier que ce sont bien les 8 premieres cases du fichier csv qui sont remplies et non la 11eme (ce qui ferait une .Length de 10 et du coup ça passerait)
                            {
                                int temp;
                                bool estUnInt = Int32.TryParse(tempTabStr[1], out temp);
                                if (estUnInt && tempTabStr[1].Length == 5) //Si le matricule est bien un nombre de 5 chiffe alors ok
                                {
                                    if (tempTabStr[2].Length != 0) // si le nom de famille est null
                                    {
                                        if (tempTabStr[3].Length != 0) // si le prenom est null
                                        {
                                            if (EstUnTypeSexeBool(tempTabStr[4]) == true) //Condition pour le sexe du sorcier
                                            {
                                                if (tempTabStr[5].Length != 0) // Condition pour la fonction attribuée au sorcier
                                                {
                                                    if (EstUnGradeBool(tempTabStr[6]) == true) //Condition pour le Grade (tatouage)
                                                    {
                                                        string[] tabStockageDesPouvoirs = TabtDesPouvoirsSorciersFromCSV(tempTabStr[7]); //Les pouvoirs sont par convention séparés d'un -
                                                        List<string> listStockageDesPouvoirs = ConvertTabStringToListString(tabStockageDesPouvoirs);
                                                        int matriculeSorcierInt = Int32.Parse(tempTabStr[1]);
                                                        TypeSexe sexeDuSorcier = ConvertStringToTypeSexe(tempTabStr[4]);
                                                        Grade gradeDuSorcier = ConvertStringToGrade(tempTabStr[6]);
                                                        //A partir de la, je suis sur que tous mes paramètres sont ok
                                                        //On peut créer un Sorcier
                                                        CSorcier nouveauSorcier = new CSorcier(matriculeSorcierInt, tempTabStr[2], tempTabStr[3], sexeDuSorcier, tempTabStr[5], gradeDuSorcier, listStockageDesPouvoirs);
                                                        Console.WriteLine("** Le " + tempTabStr[0] + " LIGNE[" + i + "] a été ajouté avec succès");
                                                        Console.ReadKey();
                                                    }
                                                    else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le Grade est incorrect dans la case 7 : " + tempTabStr[6]);
                                                }
                                                else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La fonction est null dans la case 6!");
                                            }
                                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le TypeSexe est incorrect dans la case 5 : " + tempTabStr[4]);
                                        }
                                        else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le nom de famille est null dans la case 4!");
                                    }
                                    else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le nom de famille est null dans la case 3!");
                                }
                                else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le matricule est incorrect dans la case 2 : " + tempTabStr[1]);
                            }
                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le nombre d'attributs dans le .csv est incorrect : " + tempTabStr.Length + "\nOU certains attributs ont été mal rempli dans le fichier .csv: ");

                            #endregion
                        }
                        else if (TabStr[0] == "Monstre")
                        {
                            #region Condition pour creer un monstre
                            //NOUS NOUS OCCUPONS D'UN MONSTRE
                            //Il faut enlever les deux dernieres cases du tableau car il fait automatiquement 10 de taille
                            string[] tempTabStr = new string[8]; // 7 attributs + 1 case "monstre"
                            for (int index = 0; index < tempTabStr.Length; index++)
                            {
                                tempTabStr[index] = TabStr[index];
                            }
                            //On se retrouve du coup avec un tableau de 8 comme prévu pour le monstre
                            //DisplayTabStr(tempTabStr);
                            //Le but est de blinder ce que l'on va pouvoir lire sur le fichier pour faciliter le constructeur ensuite
                            if (((tempTabStr.Length == 7 && tempTabStr[7].Length == 0) || (tempTabStr.Length == 8)) && tempTabStr.Length <= 8) // car contient 7 attributs + 1 pour la premiere case
                                                                                                                                           // Concernant les conditions d'entrées : soit 6 des 7 attributs sont remplis et le dernier pour le pouvoir est null OK
                                                                                                                                           // Soit les 7 sont entrées et c'est OK
                                                                                                                                           // Dans les 2 cas, on prend soin de vérifier que ce sont bien les 8 premieres cases du fichier csv qui sont remplies et non la 11eme (ce qui ferait une .Length de 10 et du coup ça passerait)
                            {
                                int temp;
                                bool estUnInt = Int32.TryParse(tempTabStr[1], out temp);
                                if (estUnInt && tempTabStr[1].Length == 5) //Si le matricule est bien un nombre de 5 chiffe alors ok
                                {
                                    if (tempTabStr[2].Length != 0) // si le nom de famille est null
                                    {
                                        if (tempTabStr[3].Length != 0) // si le prenom est null
                                        {
                                            if (EstUnTypeSexeBool(tempTabStr[4]) == true) //Condition pour le sexe du monstre
                                            {
                                                if (tempTabStr[5].Length != 0) // Condition pour la fonction attribuée au monstre
                                                {
                                                    estUnInt = Int32.TryParse(tempTabStr[6], out temp);
                                                    int cagnottePersonnelInt = Int32.Parse(tempTabStr[6]);
                                                    if (estUnInt && cagnottePersonnelInt >= 0 ) //Condition pour la cagnotte (int)
                                                    {
                                                        int matriculePersonnelInt = Int32.Parse(tempTabStr[1]);
                                                        TypeSexe sexeDuPersonnel = ConvertStringToTypeSexe(tempTabStr[4]);
                                                        if (tempTabStr[7].Length == 3) //Si le matricule de l'attraction est à minima un string de 3 caractères, il reste plus qu'a savoir si c'est un int
                                                        {
                                                            #region dans le cas la case "matricule attraction" est un string taille 3
                                                            estUnInt = Int32.TryParse(tempTabStr[7], out temp);
                                                            if (estUnInt) // dans le cas ou le matricule est correct
                                                            {
                                                                int matriculeAttraction = Int32.Parse(tempTabStr[7]);
                                                                //A partir de la, je suis sur que tous mes paramètres sont ok
                                                                //On peut créer un Monstre sans son attraction
                                                                CMonstre nouveauMonstre = new CMonstre(matriculePersonnelInt, tempTabStr[2], tempTabStr[3], sexeDuPersonnel, tempTabStr[5], cagnottePersonnelInt, matriculeAttraction);
                                                                Console.WriteLine("** Le " + tempTabStr[0] + " LIGNE[" + i + "] a été ajouté avec succès VOIR si une attraction doit etre affectee ulterierement : " + tempTabStr[7]);
                                                                Console.ReadKey();
                                                            }
                                                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE MONSTRE : La matricule de l'attraction est incorrect dans la case 8 : " + tempTabStr[7]);
                                                            #endregion
                                                        }
                                                        else if (tempTabStr[7].Length == 0) // on sait que dans le fichier .csv la case est vide
                                                        {
                                                            #region dans le cas ou la case "matricule attraction" est vide dans le .csv
                                                            int matriculeAttraction = 0; //le constructeur de l'attraction prend en compte le matricule = 0 (voir constructeur)
                                                            //A partir de la, je suis sur que tous mes paramètres sont ok
                                                            //On peut créer un Monstre sans son attraction
                                                            CMonstre nouveauMonstre = new CMonstre(matriculePersonnelInt, tempTabStr[2], tempTabStr[3], sexeDuPersonnel, tempTabStr[5], cagnottePersonnelInt, matriculeAttraction);
                                                            Console.WriteLine("** Le " + tempTabStr[0] + " LIGNE[" + i + "] a été ajouté avec succès AUCUNE attraction est affectee pour le moment" + tempTabStr[7]);
                                                            Console.ReadKey();
                                                            #endregion
                                                        }
                                                        else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La matricule de l'attraction est incorrect dans la case 8 : " + tempTabStr[7]);
                                                    }
                                                    else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La cagnotte est incorrecte dans la case 7 : " + tempTabStr[6]);
                                                }
                                                else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La fonction est null dans la case 6!");
                                            }
                                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le TypeSexe est incorrect dans la case 5 : " + tempTabStr[4]);
                                        }
                                        else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le nom de famille est null dans la case 4!");
                                    }
                                    else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le nom de famille est null dans la case 3!");
                                }
                                else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le matricule est incorrect dans la case 2 : " + tempTabStr[1]);
                            }
                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le nombre d'attributs dans le .csv est incorrect : " + tempTabStr.Length + "\nOU certains attributs ont été mal rempli dans le fichier .csv: ");

                            #endregion
                        }
                        else if (TabStr[0] == "Demon")
                        {
                            #region Condition pour creer un demon
                            //NOUS NOUS OCCUPONS D'UN DEMON
                            //Il faut enlever la derniere case du tableau car il fait automatiquement 10 de taille
                            string[] tempTabStr = new string[9]; // 8 attributs + 1 case "demon"
                            for (int index = 0; index < tempTabStr.Length; index++)
                            {
                                tempTabStr[index] = TabStr[index];
                            }
                            //On se retrouve du coup avec un tableau de 9 comme prévu pour le demon
                            //DisplayTabStr(tempTabStr);
                            //Le but est de blinder ce que l'on va pouvoir lire sur le fichier pour faciliter le constructeur ensuite
                            if (((tempTabStr.Length == 8 && tempTabStr[8].Length == 0) || (tempTabStr.Length == 9)) && tempTabStr.Length <= 9) // car contient 8 attributs + 1 pour la premiere case
                                                                                                                                               // Concernant les conditions d'entrées : soit 6 des 7 attributs sont remplis et le dernier pour le pouvoir est null OK
                                                                                                                                               // Soit les 7 sont entrées et c'est OK
                                                                                                                                               // Dans les 2 cas, on prend soin de vérifier que ce sont bien les 8 premieres cases du fichier csv qui sont remplies et non la 11eme (ce qui ferait une .Length de 10 et du coup ça passerait)
                            {
                                int temp;
                                bool estUnInt = Int32.TryParse(tempTabStr[1], out temp);
                                if (estUnInt && tempTabStr[1].Length == 5) //Si le matricule est bien un nombre de 5 chiffe alors ok
                                {
                                    if (tempTabStr[2].Length != 0) // si le nom de famille est null
                                    {
                                        if (tempTabStr[3].Length != 0) // si le prenom est null
                                        {
                                            if (EstUnTypeSexeBool(tempTabStr[4]) == true) //Condition pour le sexe du personnel
                                            {
                                                if (tempTabStr[5].Length != 0) // Condition pour la fonction attribuée au personnel
                                                {
                                                    estUnInt = Int32.TryParse(tempTabStr[6], out temp);
                                                    int cagnottePersonnelInt = Int32.Parse(tempTabStr[6]);
                                                    if (cagnottePersonnelInt >= 0) //Condition pour la cagnotte (int)
                                                    {
                                                        int forceDemonInt = Int32.Parse(tempTabStr[8]);
                                                        if (forceDemonInt <= 10 && forceDemonInt >= 1) // Condition pour la force du démon
                                                        {
                                                            int matriculePersonnelInt = Int32.Parse(tempTabStr[1]);
                                                            TypeSexe sexeDuPersonnel = ConvertStringToTypeSexe(tempTabStr[4]);
                                                            if (tempTabStr[7].Length == 3) //Si le matricule de l'attraction est à minima un string de 3 caractères, il reste plus qu'a savoir si c'est un int
                                                            {
                                                                #region dans le cas la case "matricule attraction" est un string taille 3
                                                                estUnInt = Int32.TryParse(tempTabStr[7], out temp);
                                                                if (estUnInt) // dans le cas ou le matricule est correct
                                                                {
                                                                    int matriculeAttraction = Int32.Parse(tempTabStr[7]);
                                                                    //A partir de la, je suis sur que tous mes paramètres sont ok
                                                                    //On peut créer un Monstre sans son attraction
                                                                    CDemon nouveauDemon = new CDemon(matriculePersonnelInt, tempTabStr[2], tempTabStr[3], sexeDuPersonnel, tempTabStr[5], cagnottePersonnelInt, matriculeAttraction, forceDemonInt);
                                                                    Console.WriteLine("** Le " + tempTabStr[0] + " LIGNE[" + i + "] a été ajouté avec succès UNE ATTRACTION doit être affectee ulterierement la n° " + tempTabStr[7]);
                                                                    Console.ReadKey();
                                                                }
                                                                else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La matricule de l'attraction est incorrect dans la case 8 : " + tempTabStr[7]);
                                                                #endregion
                                                            }
                                                            else if (tempTabStr[7].Length == 0) // on sait que dans le fichier .csv la case est vide
                                                            {
                                                                #region dans le cas ou la case "matricule attraction" est vide dans le .csv
                                                                int matriculeAttraction = 0; //le constructeur de l'attraction prend en compte le matricule = 0 (voir constructeur)
                                                                                             //A partir de la, je suis sur que tous mes paramètres sont ok
                                                                                             //On peut créer un Monstre sans son attraction
                                                                CDemon nouveauDemon = new CDemon(matriculePersonnelInt, tempTabStr[2], tempTabStr[3], sexeDuPersonnel, tempTabStr[5], cagnottePersonnelInt, matriculeAttraction, forceDemonInt);
                                                                Console.WriteLine("** Le " + tempTabStr[0] + " LIGNE[" + i + "] a été ajouté avec succès AUCUNE attraction n'est à affecter pour le moment.");
                                                                Console.ReadKey();
                                                                #endregion
                                                            }
                                                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La matricule de l'attraction est incorrect dans la case 8 : " + tempTabStr[7]);
                                                        }
                                                        else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La force du demon comprise entre 0 et 10 (int) est incorrecte dans la case 9 : " + tempTabStr[8]);
                                                    }
                                                    else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La cagnotte est incorrecte dans la case 7 : " + tempTabStr[6]);
                                                }
                                                else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La fonction est null dans la case 6!");
                                            }
                                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE" + tempTabStr[0].ToUpper() + " Le TypeSexe est incorrect dans la case 5 : " + tempTabStr[4]);
                                        }
                                        else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " Le nom de famille est null dans la case 4!");
                                    }
                                    else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + "  Le nom de famille est null dans la case 3!");
                                }
                                else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + "  Le matricule est incorrect dans la case 2 : " + tempTabStr[1]);
                            }
                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le nombre d'attributs dans le .csv est incorrect : " + tempTabStr.Length + "\nOU certains attributs ont été mal rempli dans le fichier .csv: ");

                            #endregion

                        }
                        else if (TabStr[0] == "LoupGarou")
                        {
                            #region Condition pour creer un LoupGarou
                            //NOUS NOUS OCCUPONS D'UN LoupGarou
                            //Il faut enlever la derniere case du tableau car il fait automatiquement 10 de taille
                            string[] tempTabStr = new string[9]; // 8 attributs + 1 case "loupgarou"
                            for (int index = 0; index < tempTabStr.Length; index++)
                            {
                                tempTabStr[index] = TabStr[index];
                            }
                            //On se retrouve du coup avec un tableau de 9 comme prévu pour le loupgarou
                            //DisplayTabStr(tempTabStr);
                            //Le but est de blinder ce que l'on va pouvoir lire sur le fichier pour faciliter le constructeur ensuite
                            if (((tempTabStr.Length == 8 && tempTabStr[8].Length == 0) || (tempTabStr.Length == 9)) && tempTabStr.Length <= 9) // car contient 8 attributs + 1 pour la premiere case
                                                                                                                                               // Concernant les conditions d'entrées : soit 6 des 7 attributs sont remplis et le dernier pour le pouvoir est null OK
                                                                                                                                               // Soit les 7 sont entrées et c'est OK
                                                                                                                                               // Dans les 2 cas, on prend soin de vérifier que ce sont bien les 8 premieres cases du fichier csv qui sont remplies et non la 11eme (ce qui ferait une .Length de 10 et du coup ça passerait)
                            {
                                int temp;
                                bool estUnInt = Int32.TryParse(tempTabStr[1], out temp);
                                if (estUnInt && tempTabStr[1].Length == 5) //Si le matricule est bien un nombre de 5 chiffe alors ok
                                {
                                    if (tempTabStr[2].Length != 0) // si le nom de famille est null
                                    {
                                        if (tempTabStr[3].Length != 0) // si le prenom est null
                                        {
                                            if (EstUnTypeSexeBool(tempTabStr[4]) == true) //Condition pour le sexe du personnel
                                            {
                                                if (tempTabStr[5].Length != 0) // Condition pour la fonction attribuée au personnel
                                                {
                                                    estUnInt = Int32.TryParse(tempTabStr[6], out temp);
                                                    int cagnottePersonnelInt = Int32.Parse(tempTabStr[6]);
                                                    if (cagnottePersonnelInt >= 0) //Condition pour la cagnotte (int)
                                                    {
                                                        int IndiceCruauteLoupGarouInt = Int32.Parse(tempTabStr[8]);
                                                        if (IndiceCruauteLoupGarouInt <= 4 && IndiceCruauteLoupGarouInt >= 0) // Condition pour l'indice de cruauté
                                                        {
                                                            int matriculePersonnelInt = Int32.Parse(tempTabStr[1]);
                                                            TypeSexe sexeDuPersonnel = ConvertStringToTypeSexe(tempTabStr[4]);
                                                            if (tempTabStr[7].Length == 3) //Si le matricule de l'attraction est à minima un string de 3 caractères, il reste plus qu'a savoir si c'est un int
                                                            {
                                                                #region dans le cas la case "matricule attraction" est un string taille 3
                                                                estUnInt = Int32.TryParse(tempTabStr[7], out temp);
                                                                if (estUnInt) // dans le cas ou le matricule est correct
                                                                {
                                                                    int matriculeAttraction = Int32.Parse(tempTabStr[7]);
                                                                    //A partir de la, je suis sur que tous mes paramètres sont ok
                                                                    //On peut créer un Monstre sans son attraction
                                                                    CLoupGarou nouveauLoupGarou = new CLoupGarou(matriculePersonnelInt, tempTabStr[2], tempTabStr[3], sexeDuPersonnel, tempTabStr[5], cagnottePersonnelInt, matriculeAttraction, IndiceCruauteLoupGarouInt);
                                                                    Console.WriteLine("** Le " + tempTabStr[0] + " LIGNE[" + i + "] a été ajouté avec succès UNE ATTRACTION doit être affectee ulterierement la n° " + tempTabStr[7]);
                                                                    Console.ReadKey();
                                                                }
                                                                else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La matricule de l'attraction est incorrect dans la case 8 : " + tempTabStr[7]);
                                                                #endregion
                                                            }
                                                            else if (tempTabStr[7].Length == 0) // on sait que dans le fichier .csv la case est vide
                                                            {
                                                                #region dans le cas ou la case "matricule attraction" est vide dans le .csv
                                                                int matriculeAttraction = 0; //le constructeur de l'attraction prend en compte le matricule = 0 (voir constructeur)
                                                                                             //A partir de la, je suis sur que tous mes paramètres sont ok
                                                                                             //On peut créer un Monstre sans son attraction
                                                                CLoupGarou nouveauLoupGarou = new CLoupGarou(matriculePersonnelInt, tempTabStr[2], tempTabStr[3], sexeDuPersonnel, tempTabStr[5], cagnottePersonnelInt, matriculeAttraction, IndiceCruauteLoupGarouInt);
                                                                Console.WriteLine("** Le " + tempTabStr[0] + " LIGNE[" + i + "] a été ajouté avec succès AUCUNE attraction n'est à affecter pour le moment.");
                                                                Console.ReadKey();
                                                                #endregion
                                                            }
                                                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La matricule de l'attraction est incorrect dans la case 8 : " + tempTabStr[7]);
                                                        }
                                                        else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : L'indice de cruauté compris entre 0 et 4 (int) est incorrect dans la case 9 : " + tempTabStr[8]);
                                                    }
                                                    else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La cagnotte est incorrecte dans la case 7 : " + tempTabStr[6]);
                                                }
                                                else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La fonction est null dans la case 6!");
                                            }
                                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE" + tempTabStr[0].ToUpper() + " Le TypeSexe est incorrect dans la case 5 : " + tempTabStr[4]);
                                        }
                                        else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " Le nom de famille est null dans la case 4!");
                                    }
                                    else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + "  Le nom de famille est null dans la case 3!");
                                }
                                else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + "  Le matricule est incorrect dans la case 2 : " + tempTabStr[1]);
                            }
                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le nombre d'attributs dans le .csv est incorrect : " + tempTabStr.Length + "\nOU certains attributs ont été mal rempli dans le fichier .csv: ");

                            #endregion
                        }
                        else if (TabStr[0] == "Vampire")
                        {
                            #region Condition pour creer un Vampire
                            //NOUS NOUS OCCUPONS D'UN Vampire
                            //Il faut enlever la derniere case du tableau car il fait automatiquement 10 de taille
                            string[] tempTabStr = new string[9]; // 8 attributs + 1 case "vampire"
                            for (int index = 0; index < tempTabStr.Length; index++)
                            {
                                tempTabStr[index] = TabStr[index];
                            }
                            //On se retrouve du coup avec un tableau de 9 comme prévu pour le vampire
                            //DisplayTabStr(tempTabStr);
                            //Le but est de blinder ce que l'on va pouvoir lire sur le fichier pour faciliter le constructeur ensuite
                            if (((tempTabStr.Length == 8 && tempTabStr[8].Length == 0) || (tempTabStr.Length == 9)) && tempTabStr.Length <= 9) // car contient 8 attributs + 1 pour la premiere case
                                                                                                                                               // Concernant les conditions d'entrées : soit 6 des 7 attributs sont remplis et le dernier pour le pouvoir est null OK
                                                                                                                                               // Soit les 7 sont entrées et c'est OK
                                                                                                                                               // Dans les 2 cas, on prend soin de vérifier que ce sont bien les 8 premieres cases du fichier csv qui sont remplies et non la 11eme (ce qui ferait une .Length de 10 et du coup ça passerait)
                            {
                                int temp;
                                bool estUnInt = Int32.TryParse(tempTabStr[1], out temp);
                                if (estUnInt && tempTabStr[1].Length == 5) //Si le matricule est bien un nombre de 5 chiffe alors ok
                                {
                                    if (tempTabStr[2].Length != 0) // si le nom de famille est null
                                    {
                                        if (tempTabStr[3].Length != 0) // si le prenom est null
                                        {
                                            if (EstUnTypeSexeBool(tempTabStr[4]) == true) //Condition pour le sexe du personnel
                                            {
                                                if (tempTabStr[5].Length != 0) // Condition pour la fonction attribuée au personnel
                                                {
                                                    estUnInt = Int32.TryParse(tempTabStr[6], out temp);
                                                    int cagnottePersonnelInt = Int32.Parse(tempTabStr[6]);
                                                    if (cagnottePersonnelInt >= 0) //Condition pour la cagnotte (int)
                                                    {
                                                        float IndiceLuminositeFloat = float.Parse(tempTabStr[8]);
                                                        if (IndiceLuminositeFloat <= 4 && IndiceLuminositeFloat >= 0) // Condition pour l'indice de cruauté
                                                        {
                                                            int matriculePersonnelInt = Int32.Parse(tempTabStr[1]);
                                                            TypeSexe sexeDuPersonnel = ConvertStringToTypeSexe(tempTabStr[4]);
                                                            if (tempTabStr[7].Length == 3) //Si le matricule de l'attraction est à minima un string de 3 caractères, il reste plus qu'a savoir si c'est un int
                                                            {
                                                                #region dans le cas la case "matricule attraction" est un string taille 3
                                                                estUnInt = Int32.TryParse(tempTabStr[7], out temp);
                                                                if (estUnInt) // dans le cas ou le matricule est correct
                                                                {
                                                                    int matriculeAttraction = Int32.Parse(tempTabStr[7]);
                                                                    //A partir de la, je suis sur que tous mes paramètres sont ok
                                                                    CVampire nouveauVampire = new CVampire(matriculePersonnelInt, tempTabStr[2], tempTabStr[3], sexeDuPersonnel, tempTabStr[5], cagnottePersonnelInt, matriculeAttraction, IndiceLuminositeFloat);
                                                                    Console.WriteLine("** Le " + tempTabStr[0] + " LIGNE[" + i + "] a été ajouté avec succès UNE ATTRACTION doit être affectee ulterierement la n° " + tempTabStr[7]);
                                                                    Console.ReadKey();
                                                                }
                                                                else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La matricule de l'attraction est incorrect dans la case 8 : " + tempTabStr[7]);
                                                                #endregion
                                                            }
                                                            else if (tempTabStr[7].Length == 0) // on sait que dans le fichier .csv la case est vide
                                                            {
                                                                #region dans le cas ou la case "matricule attraction" est vide dans le .csv
                                                                int matriculeAttraction = 0; //le constructeur de l'attraction prend en compte le matricule = 0 (voir constructeur)
                                                                                             //A partir de la, je suis sur que tous mes paramètres sont ok
                                                                CVampire nouveauVampire = new CVampire(matriculePersonnelInt, tempTabStr[2], tempTabStr[3], sexeDuPersonnel, tempTabStr[5], cagnottePersonnelInt, matriculeAttraction, IndiceLuminositeFloat);
                                                                Console.WriteLine("** Le " + tempTabStr[0] + " LIGNE[" + i + "] a été ajouté avec succès AUCUNE attraction n'est à affecter pour le moment.");
                                                                Console.ReadKey();
                                                                #endregion
                                                            }
                                                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La matricule de l'attraction est incorrect dans la case 8 : " + tempTabStr[7]);
                                                        }
                                                        else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : L'indice de cruauté compris entre 0 et 4 (int) est incorrect dans la case 9 : " + tempTabStr[8]);
                                                    }
                                                    else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La cagnotte est incorrecte dans la case 7 : " + tempTabStr[6]);
                                                }
                                                else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La fonction est null dans la case 6!");
                                            }
                                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE" + tempTabStr[0].ToUpper() + " Le TypeSexe est incorrect dans la case 5 : " + tempTabStr[4]);
                                        }
                                        else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " Le nom de famille est null dans la case 4!");
                                    }
                                    else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + "  Le nom de famille est null dans la case 3!");
                                }
                                else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + "  Le matricule est incorrect dans la case 2 : " + tempTabStr[1]);
                            }
                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le nombre d'attributs dans le .csv est incorrect : " + tempTabStr.Length + "\nOU certains attributs ont été mal rempli dans le fichier .csv: ");

                            #endregion
                        }
                        else if (TabStr[0] == "Fantome")
                        {
                            #region Condition pour creer un fantome
                            //NOUS NOUS OCCUPONS D'UN FANTOME
                            //Il faut enlever les deux dernieres cases du tableau car il fait automatiquement 10 de taille
                            string[] tempTabStr = new string[8]; // 8 attributs + 1 case "fantome"
                            for (int index = 0; index < tempTabStr.Length; index++)
                            {
                                tempTabStr[index] = TabStr[index];
                            }
                            //On se retrouve du coup avec un tableau de 8 comme prévu pour le monstre
                            //DisplayTabStr(tempTabStr);
                            //Le but est de blinder ce que l'on va pouvoir lire sur le fichier pour faciliter le constructeur ensuite
                            if (((tempTabStr.Length == 7 && tempTabStr[7].Length == 0) || (tempTabStr.Length == 8)) && tempTabStr.Length <= 8) // car contient 7 attributs + 1 pour la premiere case
                                                                                                                                               // Concernant les conditions d'entrées : soit 6 des 7 attributs sont remplis et le dernier pour le pouvoir est null OK
                                                                                                                                               // Soit les 7 sont entrées et c'est OK
                                                                                                                                               // Dans les 2 cas, on prend soin de vérifier que ce sont bien les 8 premieres cases du fichier csv qui sont remplies et non la 11eme (ce qui ferait une .Length de 10 et du coup ça passerait)
                            {
                                int temp;
                                bool estUnInt = Int32.TryParse(tempTabStr[1], out temp);
                                if (estUnInt && tempTabStr[1].Length == 5) //Si le matricule est bien un nombre de 5 chiffe alors ok
                                {
                                    if (tempTabStr[2].Length != 0) // si le nom de famille est null
                                    {
                                        if (tempTabStr[3].Length != 0) // si le prenom est null
                                        {
                                            if (EstUnTypeSexeBool(tempTabStr[4]) == true) //Condition pour le sexe du monstre
                                            {
                                                if (tempTabStr[5].Length != 0) // Condition pour la fonction attribuée au monstre
                                                {
                                                    estUnInt = Int32.TryParse(tempTabStr[6], out temp);
                                                    int cagnottePersonnelInt = Int32.Parse(tempTabStr[6]);
                                                    if (estUnInt && cagnottePersonnelInt >= 0) //Condition pour la cagnotte (int)
                                                    {
                                                        int matriculePersonnelInt = Int32.Parse(tempTabStr[1]);
                                                        TypeSexe sexeDuPersonnel = ConvertStringToTypeSexe(tempTabStr[4]);
                                                        if (tempTabStr[7].Length == 3) //Si le matricule de l'attraction est à minima un string de 3 caractères, il reste plus qu'a savoir si c'est un int
                                                        {
                                                            #region dans le cas la case "matricule attraction" est un string taille 3
                                                            estUnInt = Int32.TryParse(tempTabStr[7], out temp);
                                                            if (estUnInt) // dans le cas ou le matricule est correct
                                                            {
                                                                int matriculeAttraction = Int32.Parse(tempTabStr[7]);
                                                                //A partir de la, je suis sur que tous mes paramètres sont ok
                                                                //On peut créer un Monstre sans son attraction
                                                                CMonstre nouveauMonstre = new CMonstre(matriculePersonnelInt, tempTabStr[2], tempTabStr[3], sexeDuPersonnel, tempTabStr[5], cagnottePersonnelInt, matriculeAttraction);
                                                                Console.WriteLine("** Le " + tempTabStr[0] + " LIGNE[" + i + "] a été ajouté avec succès VOIR si une attraction doit etre affectee ulterierement : " + tempTabStr[7]);
                                                                Console.ReadKey();
                                                            }
                                                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE MONSTRE : La matricule de l'attraction est incorrect dans la case 8 : " + tempTabStr[7]);
                                                            #endregion
                                                        }
                                                        else if (tempTabStr[7].Length == 0) // on sait que dans le fichier .csv la case est vide
                                                        {
                                                            #region dans le cas ou la case "matricule attraction" est vide dans le .csv
                                                            int matriculeAttraction = 0; //le constructeur de l'attraction prend en compte le matricule = 0 (voir constructeur)
                                                            //A partir de la, je suis sur que tous mes paramètres sont ok
                                                            //On peut créer un Monstre sans son attraction
                                                            CMonstre nouveauMonstre = new CMonstre(matriculePersonnelInt, tempTabStr[2], tempTabStr[3], sexeDuPersonnel, tempTabStr[5], cagnottePersonnelInt, matriculeAttraction);
                                                            Console.WriteLine("** Le " + tempTabStr[0] + " LIGNE[" + i + "] a été ajouté avec succès AUCUNE attraction est affectee pour le moment" + tempTabStr[7]);
                                                            Console.ReadKey();
                                                            #endregion
                                                        }
                                                        else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La matricule de l'attraction est incorrect dans la case 8 : " + tempTabStr[7]);


                                                    }
                                                    else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La cagnotte est incorrecte dans la case 7 : " + tempTabStr[6]);
                                                }
                                                else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La fonction est null dans la case 6!");
                                            }
                                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le TypeSexe est incorrect dans la case 5 : " + tempTabStr[4]);
                                        }
                                        else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le nom de famille est null dans la case 4!");
                                    }
                                    else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le nom de famille est null dans la case 3!");
                                }
                                else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le matricule est incorrect dans la case 2 : " + tempTabStr[1]);
                            }
                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le nombre d'attributs dans le .csv est incorrect : " + tempTabStr.Length + "\nOU certains attributs ont été mal rempli dans le fichier .csv: ");

                            #endregion
                        }
                        else if (TabStr[0] == "Zombie")
                        {
                            #region Condition pour creer un zombie
                            //NOUS NOUS OCCUPONS D'UN ZOMBIE
                            string[] tempTabStr = new string[10]; // 8 attributs + 1 case "fantome"
                            for (int index = 0; index < tempTabStr.Length; index++)
                            {
                                tempTabStr[index] = TabStr[index];
                            }
                            //DisplayTabStr(tempTabStr);
                            //Le but est de blinder ce que l'on va pouvoir lire sur le fichier pour faciliter le constructeur ensuite
                            if (((tempTabStr.Length == 7 && tempTabStr[7].Length == 0) || (tempTabStr.Length == 10)) && tempTabStr.Length <= 10) // car contient 7 attributs + 1 pour la premiere case
                                                                                                                                               // Concernant les conditions d'entrées : soit 6 des 7 attributs sont remplis et le dernier pour le pouvoir est null OK
                                                                                                                                               // Soit les 7 sont entrées et c'est OK
                                                                                                                                               // Dans les 2 cas, on prend soin de vérifier que ce sont bien les 8 premieres cases du fichier csv qui sont remplies et non la 11eme (ce qui ferait une .Length de 10 et du coup ça passerait)
                            {
                                int temp;
                                bool estUnInt = Int32.TryParse(tempTabStr[1], out temp);
                                if (estUnInt && tempTabStr[1].Length == 5) //Si le matricule est bien un nombre de 5 chiffe alors ok
                                {
                                    if (tempTabStr[2].Length != 0) // si le nom de famille est null
                                    {
                                        if (tempTabStr[3].Length != 0) // si le prenom est null
                                        {
                                            if (EstUnTypeSexeBool(tempTabStr[4]) == true) //Condition pour le sexe du monstre
                                            {
                                                if (tempTabStr[5].Length != 0) // Condition pour la fonction attribuée au monstre
                                                {
                                                    estUnInt = Int32.TryParse(tempTabStr[6], out temp);
                                                    int cagnottePersonnelInt = Int32.Parse(tempTabStr[6]);
                                                    if (estUnInt && cagnottePersonnelInt >= 0) //Condition pour la cagnotte (int)
                                                    {
                                                        if (EstUnCouleurZBool(tempTabStr[8])) // Condition pour le couleur Zombie
                                                        {
                                                            int DegreDecompositionInt = Int32.Parse(tempTabStr[9]);
                                                            if (DegreDecompositionInt <= 10 && DegreDecompositionInt >= 1) // Condition pour le degre de decomposition
                                                            {
                                                                int matriculePersonnelInt = Int32.Parse(tempTabStr[1]);
                                                                TypeSexe sexeDuPersonnel = ConvertStringToTypeSexe(tempTabStr[4]);
                                                                CouleurZ couleurDuZombie = ConvertStringToCouleurZ(tempTabStr[8]);
                                                                if (tempTabStr[7].Length == 3) //Si le matricule de l'attraction est à minima un string de 3 caractères, il reste plus qu'a savoir si c'est un int
                                                                {
                                                                    #region dans le cas la case "matricule attraction" est un string taille 3
                                                                    estUnInt = Int32.TryParse(tempTabStr[7], out temp);
                                                                    if (estUnInt) // dans le cas ou le matricule est correct
                                                                    {
                                                                        int matriculeAttraction = Int32.Parse(tempTabStr[7]);
                                                                        //A partir de la, je suis sur que tous mes paramètres sont ok
                                                                        //On peut créer un Monstre sans son attraction
                                                                        CZombie nouveauZombie = new CZombie(matriculePersonnelInt, tempTabStr[2], tempTabStr[3], sexeDuPersonnel, tempTabStr[5], cagnottePersonnelInt, matriculeAttraction, couleurDuZombie, DegreDecompositionInt);
                                                                        Console.WriteLine("** Le " + tempTabStr[0] + " LIGNE[" + i + "] a été ajouté avec succès VOIR si une attraction doit etre affectee ulterierement : " + tempTabStr[7]);
                                                                        Console.ReadKey();
                                                                    }
                                                                    else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE MONSTRE : La matricule de l'attraction est incorrect dans la case 8 : " + tempTabStr[7]);
                                                                    #endregion
                                                                }
                                                                else if (tempTabStr[7].Length == 0) // on sait que dans le fichier .csv la case est vide
                                                                {
                                                                    #region dans le cas ou la case "matricule attraction" est vide dans le .csv
                                                                    int matriculeAttraction = 0; //le constructeur de l'attraction prend en compte le matricule = 0 (voir constructeur)
                                                                                                 //A partir de la, je suis sur que tous mes paramètres sont ok
                                                                                                 //On peut créer un Monstre sans son attraction
                                                                    CZombie nouveauZombie = new CZombie(matriculePersonnelInt, tempTabStr[2], tempTabStr[3], sexeDuPersonnel, tempTabStr[5], cagnottePersonnelInt, matriculeAttraction, couleurDuZombie, DegreDecompositionInt);
                                                                    Console.WriteLine("** Le " + tempTabStr[0] + " LIGNE[" + i + "] a été ajouté avec succès AUCUNE attraction est affectee pour le moment" + tempTabStr[7]);
                                                                    Console.ReadKey();
                                                                    #endregion
                                                                }
                                                                else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La matricule de l'attraction est incorrect dans la case 8 : " + tempTabStr[7]);
                                                            }
                                                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le degre de decomposition est incorrect dans la case 10 : " + tempTabStr[9]);
                                                        }
                                                        else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La couleur lue est incorrecte dans la case 9 : " + tempTabStr[8]);
                                                    }
                                                    else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La cagnotte est incorrecte dans la case 7 : " + tempTabStr[6]);
                                                }
                                                else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : La fonction est null dans la case 6!");
                                            }
                                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le TypeSexe est incorrect dans la case 5 : " + tempTabStr[4]);
                                        }
                                        else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le nom de famille est null dans la case 4!");
                                    }
                                    else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le nom de famille est null dans la case 3!");
                                }
                                else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le matricule est incorrect dans la case 2 : " + tempTabStr[1]);
                            }
                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le nombre d'attributs dans le .csv est incorrect : " + tempTabStr.Length + "\nOU certains attributs ont été mal rempli dans le fichier .csv: ");

                            #endregion
                        }
                        else if (TabStr[0] == "Boutique")
                        {
                            #region Condition pour creer une boutique
                            //NOUS NOUS OCCUPONS D'UN BOUTIQUE
                            //Il faut enlever la derniere case du tableau car il fait automatiquement 10 de taille
                            string[] tempTabStr = new string[7]; // 6 attributs + 1 case "boutique"
                            for (int index = 0; index < tempTabStr.Length; index++)
                            {
                                tempTabStr[index] = TabStr[index];
                            }
                            //On se retrouve du coup avec un tableau de 7 comme prévu pour la boutique
                            //DisplayTabStr(tempTabStr);
                            //Le but est de blinder ce que l'on va pouvoir lire sur le fichier pour faciliter le constructeur ensuite
                            if (tempTabStr.Length <= 7) // car contient 6 attributs + 1 pour la premiere case
                            {
                                int temp;
                                bool estUnInt = Int32.TryParse(tempTabStr[1], out temp);
                                int matriculeAttractionInt = Int32.Parse(tempTabStr[1]);
                                if (matriculeAttractionInt >= 0 && tempTabStr[1].Length == 3) //Si le matricule est bien un nombre de 3 chiffes alors ok
                                {
                                    if (tempTabStr[2].Length != 0) // si le nom de l'attraction est null
                                    {
                                        int nombreMinimumPersonnelAttraction = Int32.Parse(tempTabStr[3]);
                                        if (nombreMinimumPersonnelAttraction > 0) // nombre de monstre minimum affecté à l'attraction (au moins 1, peut pas etre negatif)
                                        {
                                            bool besoinSpecifiqueAttraction = bool.Parse(tempTabStr[4]); //Besoin spécifique sur l'attraction ? Oui/non
                                            string besoinAttractionStr = besoinSpecifiqueLectureCsv(tempTabStr[5], besoinSpecifiqueAttraction); //stockage du besoin éventuel
                                            if (EstUnTypeBoutiqueBool(tempTabStr[6]) == true) //Verif sur la nature du type de boutique
                                            {
                                                TypeBoutique typeDeLaBoutique = ConvertStringToTypeBoutique(tempTabStr[6]);
                                                CBoutique nouvelleBoutique = new CBoutique(matriculeAttractionInt, tempTabStr[2], nombreMinimumPersonnelAttraction, besoinSpecifiqueAttraction, besoinAttractionStr, typeDeLaBoutique);
                                                Console.WriteLine("** La " + tempTabStr[0] + " LIGNE[" + i + "] a été ajoutée avec succès");
                                                Console.ReadKey();
                                            }
                                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le TypeBoutique est incorrect dans la case 7 : " + tempTabStr[6]);
                                        }
                                        else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le nombre minimum de personnel est inférieur à 0 dans la case 4!");
                                    }
                                    else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le nom de l'attraction est null dans la case 3!");
                                }
                                else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le matricule est incorrect dans la case 2 : " + tempTabStr[1]);
                            }
                            else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA BOUCLE " + tempTabStr[0].ToUpper() + " : Le nombre d'attributs dans le .csv est incorrect : " + tempTabStr.Length + "\nOU certains attributs ont été mal rempli dans le fichier .csv: ");

                            #endregion
                        }
                        else if (TabStr[0] == "Spectacles")
                        {

                        }
                        else if (TabStr[0] == "DarkRide")
                        {

                        }
                        else if (TabStr[0] == "RollerCoaster")
                        {

                        }
                        else throw new Exception("\nLIGNE[" + i + "] ERREUR POUR LA CASE 1 : Le type d'objet n'est pas reconnu pour le parc : " + TabStr[0]);
                    }
                    catch(Exception e)
                    {
                        Console.WriteLine("\nERREUR DANS LECTUREFICHIERCSV LIGNE[" + i + "] : " + e.Message);
                    }
                    i++;
                    ligneLuStr = monStreamReader.ReadLine(); //Lecture de la ligne suivante
                }
                //Il faut maintenant vérifier si toutes les affectations aux attractions chez les monstres est valide

                // Et on oublie pas de fermer le flux
                monStreamReader.Close();
                #endregion
            }
            catch (Exception e)
            {
                Console.WriteLine("ERREUR FICHIER DANS LECTUREFICHIERCSV : " + e.Message);
            }

        }

        static bool EstUnTypeSexeBool(string chaineStr)
        {
            bool resultReturedBool = false;
            try
            {
                if (chaineStr == "femelle" || chaineStr == "male" || chaineStr == "autre")
                {
                    resultReturedBool = true;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return resultReturedBool;
        }

        static bool EstUnCouleurZBool(string chaineStr)
        {
            bool resultReturedBool = false;
            try
            {
                if (chaineStr == "bleuatre" || chaineStr == "grisatre")
                {
                    resultReturedBool = true;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return resultReturedBool;
        }
         
        static bool EstUnTypeBoutiqueBool(string chaineStr)
        {
            bool resultReturedBool = false;
            try
            {
                if (chaineStr == "souvenir" || chaineStr == "barbeAPapa" || chaineStr == "nourriture")
                {
                    resultReturedBool = true;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return resultReturedBool;
        }

        static bool EstUnGradeBool(string chaineStr)
        {
            bool resultReturedBool = false;
            try
            {
                if (chaineStr == "novice" || chaineStr == "mega" || chaineStr == "giga" || chaineStr == "strata")
                {
                    resultReturedBool = true;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return resultReturedBool;
        }

        static string[] TabtDesPouvoirsSorciersFromCSV(string chaineStr) //Les pouvoirs sont séparés d'un -
        {
            string[] tabDesPouvoirsStr;
            tabDesPouvoirsStr = chaineStr.Split('-');
            return tabDesPouvoirsStr;
            
        }

        static void DisplayTabStr(string[] tab)
        {
            for(int i = 0; i< tab.Length; i++)
            {
                Console.WriteLine("Mot " + (i + 1) + " : " + tab[i]);
            }
        }

        static List<string> ConvertTabStringToListString(string[] tab)
        {
            List<string> listReturned = new List<string>();
            for(int i = 0; i< tab.Length;i++)
            {
                listReturned.Add(tab[i]);
            }
            return listReturned;
        }

        static TypeSexe ConvertStringToTypeSexe(string chaineStr)
        {
            TypeSexe valueReturned = new TypeSexe();
            if(chaineStr != null)
            {
                try
                {
                    if (chaineStr == "male") valueReturned = TypeSexe.male;
                    else if (chaineStr == "femelle") valueReturned = TypeSexe.femelle;
                    else if (chaineStr == "autre") valueReturned = TypeSexe.autre;
                    else throw new Exception("!!! ATTENTION !!! il y a eu une erreur, le sexe a été mis par default sur .autre !!");
                }
                catch(Exception e)
                {
                    Console.WriteLine("ERREUR DANS CONVERTSTRINGTOTYPESEXE : " + e.Message);
                }
            }
            return valueReturned;
        }

        static TypeBoutique ConvertStringToTypeBoutique(string chaineStr)
        {
            TypeBoutique valueReturned = TypeBoutique.souvenir;
            if (chaineStr != null)
            {
                try
                {
                    if (chaineStr == "souvenir") valueReturned = TypeBoutique.souvenir;
                    else if (chaineStr == "nourriture") valueReturned = TypeBoutique.nourriture;
                    else if (chaineStr == "barbeAPapa") valueReturned = TypeBoutique.barbeAPapa;
                    else throw new Exception("!!! ATTENTION !!! il y a eu une erreur, le type de la boutique a été mis par default sur .souvenir !!");
                }
                catch (Exception e)
                {
                    Console.WriteLine("ERREUR DANS CONVERTSTRINGTOTYPESEXE : " + e.Message);
                }
            }
            return valueReturned;
        }

        static Grade ConvertStringToGrade(string chaineStr)
        {
            Grade valueReturned = Grade.giga;
            if (chaineStr != null)
            {
                try
                {
                    if (chaineStr == "giga") valueReturned = Grade.giga;
                    else if (chaineStr == "strata") valueReturned = Grade.strata;
                    else if (chaineStr == "mega") valueReturned = Grade.mega;
                    else if (chaineStr == "novice") valueReturned = Grade.novice;
                    else throw new Exception("!!! ATTENTION !!! il y a eu une erreur, le grade a été mis par default sur .giga !!");
                }
                catch (Exception e)
                {
                    Console.WriteLine("ERREUR DANS CONVERTSTRINGTOGRADE : " + e.Message);
                }
            }
            return valueReturned;
        }

        static CouleurZ ConvertStringToCouleurZ(string chaineStr)
        {
            CouleurZ valueReturned = CouleurZ.grisatre;
            if (chaineStr != null)
            {
                try
                {
                    if (chaineStr == "bleuatre") valueReturned = CouleurZ.bleuatre;
                    else if (chaineStr == "grisatre") valueReturned = CouleurZ.grisatre;
                    else throw new Exception("!!! ATTENTION !!! il y a eu une erreur, la couleurZa été mise par default sur .grisatre !! Appuyer sur une touche pour continuer ...");
                }
                catch (Exception e)
                {
                    Console.WriteLine("ERREUR DANS CONVERTSTRINGTOCOULEURZ : " + e.Message);
                    Console.ReadKey();
                }
            }
            return valueReturned;
        }

        static string besoinSpecifiqueLectureCsv(string chaineStr, bool besoinSpecifiqueBool)
        {
            string besoinSpecifiqueReturned = "";
            if(besoinSpecifiqueBool) //dans le cas ou le csv indique qu'il faut bien un besoin //autrement on retourne rien
            {
                besoinSpecifiqueReturned = chaineStr;
            }
            return besoinSpecifiqueReturned;
        }
    }
}
