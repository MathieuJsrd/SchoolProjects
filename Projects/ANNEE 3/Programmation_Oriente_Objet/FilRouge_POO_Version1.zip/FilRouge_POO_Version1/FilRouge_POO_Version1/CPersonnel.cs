﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge_POO_Version1
{
    class CPersonnel
    {
        protected string m_fonctionStr;
        protected int m_matriculeInt;
        protected string m_nomStr;
        protected string m_prenomStr;
        protected TypeSexe m_sexeTypeSexe;

        public CPersonnel(int matriculeInt, string nomStr, string prenomStr, TypeSexe sexeTypeSexe, string fonctionStr)
        {
            try
            {
                m_matriculeInt = matriculeInt;
                m_nomStr = nomStr;
                m_prenomStr = prenomStr;
                m_sexeTypeSexe = sexeTypeSexe;
                m_fonctionStr = fonctionStr;
                // Le fait que ce soit bien des int ou des string est faire dans la lecture fichier
                //Si la string lu dans le csv est convertible en int et length = 5 alors on dit : m_matriculeInt = matriculeInt; else throw new Exception ("Matricule invalide (int)" + m_matriculeInt)
            }
            catch (Exception e)
            {
                Console.WriteLine("ERREUR DANS CONSTRUCTEUR CPERSONNEL : " + e.Message);
            }
        }

        public string DisplayObject()
        {
            string messageStrReturned = "";
            messageStrReturned = "L'objet CPersonnel : \nMatricule : " + m_matriculeInt + "\nNom : " + m_nomStr + "\nPrenom : " + m_prenomStr + "\nSexe : " + m_sexeTypeSexe + "\nFonction : " + m_fonctionStr + "\n\n";
            return messageStrReturned;
        }
        
    }
}
