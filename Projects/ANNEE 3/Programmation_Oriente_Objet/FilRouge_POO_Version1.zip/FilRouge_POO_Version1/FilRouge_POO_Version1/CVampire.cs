﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge_POO_Version1
{
    class CVampire : CMonstre
    {
        private float m_indiceLuminositeFloat;

        public CVampire(int matricule, string nom, string prenom, TypeSexe sexe, string fonction, int cagnotte, CAttraction affectation, float luminosite):base(matricule,nom,prenom,sexe,fonction,cagnotte,affectation)
        {
            m_indiceLuminositeFloat = luminosite;
        }
        public CVampire(int matricule, string nom, string prenom, TypeSexe sexe, string fonction, int cagnotte, int IDaffectationAttraction, float luminosite) : base(matricule, nom, prenom, sexe, fonction, cagnotte, IDaffectationAttraction)
        {
            m_indiceLuminositeFloat = luminosite;
        }
    }
}
