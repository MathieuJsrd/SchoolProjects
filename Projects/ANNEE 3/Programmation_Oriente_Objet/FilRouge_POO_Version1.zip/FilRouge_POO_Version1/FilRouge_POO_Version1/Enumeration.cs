﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge_POO_Version1
{
    public enum TypeSexe { male, femelle, autre };
    public enum Grade { novice, mega, giga, strata};
    public enum TypeBoutique { souvenir, barbeAPapa, nourriture};
    public enum TypeCategorie { assise, inversee, bobsleigh};
    public enum CouleurZ { bleuatre, grisatre};
}
