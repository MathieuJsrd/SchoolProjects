﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge_POO_Version1
{
    class CBoutique : CAttraction
    {
        private TypeBoutique m_typeBoutiq;

        public CBoutique(int identifiant, string nom, int nbMinMonstre, bool besoinSpecifique, string typeDeBesoin, TypeBoutique typeBoutiq):base(identifiant,nom,nbMinMonstre,besoinSpecifique,typeDeBesoin)
        {
            m_typeBoutiq = typeBoutiq;
        }

    }
}
