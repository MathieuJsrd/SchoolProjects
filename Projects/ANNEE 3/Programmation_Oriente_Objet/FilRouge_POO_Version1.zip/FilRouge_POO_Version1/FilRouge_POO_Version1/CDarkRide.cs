﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge_POO_Version1
{
    class CDarkRide : CAttraction
    {
        private TimeSpan m_dureeTimeSpan;
        private bool m_vehiculeBool;
        public CDarkRide(int identifiant, string nom, int nbMinMonstre, bool besoinSpecifique, string typeDeBesoin, TimeSpan duree, bool vehicule):base(identifiant,nom,nbMinMonstre,besoinSpecifique,typeDeBesoin)
        {
            m_dureeMaintenanceTimeSpan = duree;
            m_vehiculeBool = vehicule;
        }
    }
}
