﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge_POO_Version1
{
    class CZombie : CMonstre
    {
        private int m_degreDecompositionInt;
        private CouleurZ m_teintCouleurZ;

        public CZombie(int matricule, string nom, string prenom, TypeSexe sexe, string fonction, int cagnotte, CAttraction affectation, CouleurZ teint, int degreDecomposition):base(matricule,nom,prenom,sexe,fonction,cagnotte,affectation)
        {
            m_degreDecompositionInt = degreDecomposition;
            m_teintCouleurZ = teint;
        }
        public CZombie(int matricule, string nom, string prenom, TypeSexe sexe, string fonction, int cagnotte, int IDaffectationAttraction, CouleurZ teint, int degreDecomposition) : base(matricule, nom, prenom, sexe, fonction, cagnotte, IDaffectationAttraction)
        {
            m_degreDecompositionInt = degreDecomposition;
            m_teintCouleurZ = teint;
        }
    }
}
