﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge_POO_Version1
{
    class CFantome : CMonstre
    {
        public CFantome(int matricule, string nom, string prenom, TypeSexe sexe, string fonction, int cagnotte, CAttraction affectation):base(matricule,nom,prenom,sexe,fonction, cagnotte,affectation)
        {
        }
    }
}
