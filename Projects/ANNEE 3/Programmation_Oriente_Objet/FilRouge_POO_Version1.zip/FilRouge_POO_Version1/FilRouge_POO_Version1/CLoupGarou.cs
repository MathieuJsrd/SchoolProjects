﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge_POO_Version1
{
    class CLoupGarou : CMonstre
    {
        private double m_indiceCruauteDbl;

        public CLoupGarou(int matricule, string nom, string prenom, TypeSexe sexe, string fonction,  int cagnotte, CAttraction affectation, double indiceCruaute):base(matricule,nom,prenom,sexe,fonction,cagnotte,affectation)
        {
            m_indiceCruauteDbl = indiceCruaute;
        }
        public CLoupGarou(int matricule, string nom, string prenom, TypeSexe sexe, string fonction, int cagnotte, int IDaffectationAttraction, double indiceCruaute) : base(matricule, nom, prenom, sexe, fonction, cagnotte, IDaffectationAttraction)
        {
            m_indiceCruauteDbl = indiceCruaute;
        }
    }
}
