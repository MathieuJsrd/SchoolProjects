﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge_POO_Version1
{
    interface IAffectationAttractionPersonnel
    {
        string AjouterUneAffectationAttraction(CAttraction affectation);
    }
}
