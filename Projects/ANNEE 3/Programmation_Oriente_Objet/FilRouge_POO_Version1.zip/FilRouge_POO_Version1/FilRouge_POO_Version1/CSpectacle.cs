﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FilRouge_POO_Version1
{
    class CSpectacle : CAttraction
    {
        private List<DateTime> m_horaireListDateTime;
        private int m_nombrePlaceInt;
        private string m_nomSalleStr;

        public CSpectacle(int identifiant, string nom, int nbMinMonstre, bool besoinSpecifique, string typeDeBesoin, string nomSalle, int nombrePlaces, List<DateTime> horaire):base(identifiant,nom,nbMinMonstre,besoinSpecifique,typeDeBesoin)
        {
            m_horaireListDateTime = horaire;
            m_nombrePlaceInt = nombrePlaces;
            m_nomSalleStr = nomSalle;
        }
    }
}
